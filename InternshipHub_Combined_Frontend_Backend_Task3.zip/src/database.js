const Database = require("better-sqlite3");
const seed = [
 ["Frontend Developer Intern","Demo Technology","Hyderabad, India","hybrid",["HTML","CSS","JavaScript"],"Build responsive websites and learn frontend development."],
 ["Data Analyst Intern","Demo Analytics","Remote","remote",["Python","SQL","Excel"],"Analyze data and prepare reports."],
 ["Backend Developer Intern","Demo Software","Bengaluru, India","onsite",["Node.js","REST API","SQL"],"Learn backend development and database integration."],
 ["Digital Marketing Intern","Demo Media","Remote","remote",["SEO","Content","Analytics"],"Help plan digital campaigns."],
 ["UI/UX Design Intern","Demo Creative","Hyderabad, India","hybrid",["Figma","Design","Prototyping"],"Create user-friendly interfaces."],
 ["Business Operations Intern","Demo Business","Pune, India","onsite",["Research","Excel","Communication"],"Support business research and operations."]
];
function createDatabase(file=":memory:") {
 const db=new Database(file); db.pragma("foreign_keys = ON");
 db.exec(`CREATE TABLE IF NOT EXISTS opportunities(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,company TEXT NOT NULL,location TEXT NOT NULL,work_mode TEXT NOT NULL CHECK(work_mode IN ('remote','hybrid','onsite')),skills TEXT NOT NULL,description TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',apply_url TEXT NOT NULL DEFAULT '');
 CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY AUTOINCREMENT,opportunity_id INTEGER NOT NULL,full_name TEXT NOT NULL,email TEXT NOT NULL,phone TEXT,cover_letter TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(opportunity_id) REFERENCES opportunities(id));`);
 if(!db.prepare("SELECT COUNT(*) n FROM opportunities").get().n){
  const stmt=db.prepare("INSERT INTO opportunities(title,company,location,work_mode,skills,description,status,apply_url) VALUES(?,?,?,?,?,?,'open','')");
  const insert=db.transaction(rows=>rows.forEach(r=>stmt.run(r[0],r[1],r[2],r[3],JSON.stringify(r[4]),r[5])));
  insert(seed);
 }
 return db;
}
module.exports={createDatabase};
