# Test report template

Project: InternshipHub Secure Application Integration  
Command: `npm test`  
Framework: Node.js test runner + Supertest  
Database: in-memory SQLite in API tests

Coverage:
- Health endpoint and security headers
- Opportunity listing and safe search
- Valid application accepted
- Invalid application rejected
- Unknown opportunity rejected
- Invalid filter rejected
- Field validation for name, email, ID and cover-letter length

Run `npm install` then `npm test`. Paste the actual terminal summary here before submitting. This template intentionally does not claim tests passed before execution.
