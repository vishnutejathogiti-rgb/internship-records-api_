const express=require("express");
const helmet=require("helmet");
const rateLimit=require("express-rate-limit");
const path=require("node:path");
const {createDatabase}=require("./src/database");
const {validateApplication}=require("./src/validation");

function createApp({db=createDatabase()}={}) {
 const app=express(); app.disable("x-powered-by"); app.use(helmet()); app.use(express.json({limit:"20kb"}));
 app.use("/api",rateLimit({windowMs:15*60*1000,limit:100,standardHeaders:"draft-7",legacyHeaders:false,message:{error:"Too many requests. Try later."}}));
 const applicationLimit=rateLimit({windowMs:15*60*1000,limit:8,standardHeaders:"draft-7",legacyHeaders:false,message:{error:"Too many application attempts. Try later."}});
 app.get("/api/health",(_req,res)=>res.json({status:"ok"}));
 app.get("/api/opportunities",(req,res)=>{
  const q=String(req.query.q||"").trim().slice(0,100), mode=String(req.query.mode||"").toLowerCase();
  if(!["","remote","hybrid","onsite"].includes(mode)) return res.status(400).json({error:"Invalid work mode."});
  const sql=`SELECT id,title,company,location,work_mode AS workMode,skills,description,status,apply_url AS applyUrl FROM opportunities WHERE (?='' OR work_mode=?) AND (?='' OR title LIKE ? OR company LIKE ? OR location LIKE ? OR skills LIKE ?) ORDER BY id`;
  const rows=db.prepare(sql).all(mode,mode,q,`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`);
  res.json({data:rows.map(r=>({...r,skills:JSON.parse(r.skills)}))});
 });
 app.get("/api/opportunities/:id",(req,res)=>{
  const id=Number(req.params.id);
  if(!Number.isSafeInteger(id)||id<1)return res.status(400).json({error:"Invalid opportunity ID."});
  const row=db.prepare("SELECT id,title,company,location,work_mode AS workMode,skills,description,status,apply_url AS applyUrl FROM opportunities WHERE id=?").get(id);
  if(!row)return res.status(404).json({error:"Opportunity not found."});
  res.json({data:{...row,skills:JSON.parse(row.skills)}});
 });
 app.post("/api/applications",applicationLimit,(req,res)=>{
  const v=validateApplication(req.body);
  if(!v.valid)return res.status(400).json({error:"Please correct the highlighted fields.",fields:v.errors});
  const x=v.value, opportunity=db.prepare("SELECT id,status FROM opportunities WHERE id=?").get(x.opportunityId);
  if(!opportunity)return res.status(404).json({error:"Opportunity not found."});
  if(opportunity.status!=="open")return res.status(409).json({error:"Applications are closed for this opportunity."});
  try{
   const result=db.prepare("INSERT INTO applications(opportunity_id,full_name,email,phone,cover_letter) VALUES(?,?,?,?,?)").run(x.opportunityId,x.fullName,x.email,x.phone||null,x.coverLetter||null);
   res.status(201).json({message:"Application submitted successfully.",applicationId:result.lastInsertRowid});
  }catch(e){console.error("Application insert failed:",e.message);res.status(500).json({error:"Unable to submit application right now."});}
 });
 app.use(express.static(path.join(__dirname,"public")));
 app.use((req,res)=>req.path.startsWith("/api/")?res.status(404).json({error:"API endpoint not found."}):res.status(404).send("Page not found."));
 app.locals.db=db; return app;
}
if(require.main===module){const app=createApp();app.listen(process.env.PORT||3000,()=>console.log("InternshipHub running on port "+(process.env.PORT||3000)));}
module.exports={createApp};
