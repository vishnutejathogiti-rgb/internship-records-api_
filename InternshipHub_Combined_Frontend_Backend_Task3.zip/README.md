# InternshipHub — Secure Application Integration

Full-stack internship board with API-backed listings, client/server validation, rate limiting, Helmet security headers, parameterized SQLite queries, and automated tests.

## Run locally
Requires Node.js 20+.
```bash
npm install
npm start
```
Open http://localhost:3000

Run tests:
```bash
npm test
```

## API
- `GET /api/health`
- `GET /api/opportunities` (optional `q` and `mode=remote|hybrid|onsite`)
- `GET /api/opportunities/:id`
- `POST /api/applications`

Example POST body:
```json
{"opportunityId":1,"fullName":"Asha Kumar","email":"asha@example.com","phone":"+91 9876543210","coverLetter":"I am interested in this opportunity."}
```

## Security checklist
- [x] Helmet secure headers
- [x] API rate limit (100 requests / 15 minutes)
- [x] Application submission rate limit (8 / 15 minutes)
- [x] 20 KB JSON body limit
- [x] Server-side validation; browser validation is only a usability layer
- [x] SQL prepared statements and bound parameters
- [x] Open opportunity verified before accepting application
- [x] User input rendered with `textContent`
- [ ] Configure HTTPS and persistent database storage on hosting
- [ ] Add a privacy notice, retention policy, backups, monitoring and spam controls before production

## Test evidence
Run `npm test`; record the actual terminal output in `docs/TEST_REPORT.md`. Do not claim tests passed until run.

## Deployment
GitHub Pages cannot run the Express backend. Deploy this repository to a Node.js host that supports persistent storage, or use a managed database if the host filesystem is ephemeral.
